<?php
  $sql=mysqli_connect('localhost','root','','hotelms');

  if($sql==true)
  {
     
  }
  

?>