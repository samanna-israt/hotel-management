<?php
include('header.php');
include('dbcon.php');
session_start();

?>
<style>
    .food-nav{
        display: flex;
        width: 100%;
        margin-top: 30px;
        position: sticky;
        top:0px;
        background-color:crimson;
        border-radius:50px;
        
    }
    .food-nav ul{
        display: flex;
        padding: 10px;
        align-items: center;
        justify-content: center;
        margin-left: 50px;
    }
    .food-nav ul li{
        list-style: none;
        padding: 10px;
        text-align:center;
        margin-left: 70px;
    }
    .food-nav ul li:hover{
        background-color:white;
        color:white;
        border-radius:10px;
    }
    .food-nav ul li a{
        text-decoration: none;
        font-size:20px;
        text-align:center;
        color:black;
        font-weight:700;
    }
    .food-h{
        text-align:center;
    }
</style>
<nav class="food-nav">
    <ul>

        <li><a href="#italian">Italian</a></li>
        <li><a href="#chinese">Chinese</a></li>
        <li><a href="#deserts">Deserts</a></li>
    </ul>
</nav>

<div class="container">

    <!-- ================================== Italian===================================== -->
    <h1 class="food-h">Italian</h1>
    <div class="row" id="italian">
       
        <div class="col-lg-3">
           
        <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/chillipasta.jpg" alt="pasta">
                <div class="card-body">
                    <h5 class="card-title">Chilli Pasta</h5>
                    <p class="card-text">Price : tk 200</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Chili Pasta">
                   <input type="hidden" name="price" value="200">
                </div>
            </div>
            </form>
        </div>

        <div class="col-lg-3">
            <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/burger.jpg" alt="Burger">
                <div class="card-body">
                    <h5 class="card-title">Veg Cheese Burger</h5>
                    <p class="card-text">Price : tk 110</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Burger">
                   <input type="hidden" name="price" value="110">
                </div>
            </div>
            </form>
        </div>

        <div class="col-lg-3">
        <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/pasta.png" alt="pasta">
                <div class="card-body">
                    <h5 class="card-title">Pasta</h5>
                    <p class="card-text">Price : tk 160</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Pasta">
                   <input type="hidden" name="price" value="160">
                </div>
            </div>
            </form>
        </div>
        <div class="col-lg-3">
        <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/pizza.jpg" alt="">
                <div class="card-body">
                    <h5 class="card-title">Pizza</h5>
                    <p class="card-text">Price : tk 250</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Pizza">
                   <input type="hidden" name="price" value="250">
                </div>
            </div>
            </form>
        </div>

        <div class="col-lg-3">
        <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/margereta.jpg" alt="margereta">
                <div class="card-body">
                    <h5 class="card-title">Margereta</h5>
                    <p class="card-text">Price : tk 150</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Margereta">
                   <input type="hidden" name="price" value="150">
                </div>
            </div>
            </form>
        </div>
        <div class="col-lg-3">
        <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="img/capsi.jpg" alt="capsi">
                <div class="card-body">
                    <h5 class="card-title">New Capsi Pizza</h5>
                    <p class="card-text">Price : tk 160</p>
                   <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                   <input type="hidden" name="item_name" value="Capsi Pizza">
                   <input type="hidden" name="price" value="160">
                </div>
            </div>
            </form>
            
        </div>
       
      
        
    </div>

   <!-- ------------------------------------------chinese-------------------------- -->
   <h1 class="food-h">Chinese</h1>
   <div class="row" id="chinese">
       
       <div class="col-lg-3">
          
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/paneerchilli.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Paneer Chili</h5>
                   <p class="card-text">Price : tk 120</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Paneer Chili">
                  <input type="hidden" name="price" value="120">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
           <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/manchu.png" alt="">
               <div class="card-body">
                   <h5 class="card-title">Manchurion</h5>
                   <p class="card-text">Price : tk 110</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Manchurion">
                  <input type="hidden" name="price" value="110">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/sezwan.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Sezwan Rice</h5>
                   <p class="card-text">Price : tk 160</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Sezwan">
                  <input type="hidden" name="price" value="160">
               </div>
           </div>
           </form>
       </div>
       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/nood.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Veg Dry Noodles</h5>
                   <p class="card-text">Price : tk 120</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Dry Noodels">
                  <input type="hidden" name="price" value="120">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/momo.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Boiled Momos</h5>
                   <p class="card-text">Price : tk 170</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Momos">
                  <input type="hidden" name="price" value="170">
               </div>
           </div>
           </form>
       </div>
       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/hakka.jpg" alt="hakks">
               <div class="card-body">
                   <h5 class="card-title">Paneer Butter Masala</h5>
                   <p class="card-text">Price : tk 110</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Hakka">
                  <input type="hidden" name="price" value="110">
               </div>
           </div>
           </form>
           
       </div>
      
     
       
   </div>
   <!-- ---------------------------------------------deserts---------------------------------- -->
   <h1 class="food-h">Deserts</h1>
   <div class="row" id="deserts">
       
       <div class="col-lg-3">
          
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/faluda.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Faluda</h5>
                   <p class="card-text">Price : tk 100</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Faluda">
                  <input type="hidden" name="price" value="100">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
           <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/chocochips.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Choco Chips Ice-cream</h5>
                   <p class="card-text">Price : tk 70</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Chocochips">
                  <input type="hidden" name="price" value="70">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/cmilkshake.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Chocolate Milkshake</h5>
                   <p class="card-text">Price : tk 110</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Chocolate Milk">
                  <input type="hidden" name="price" value="110">
               </div>
           </div>
           </form>
       </div>
       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/mangomilk.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Mango Milk Shake</h5>
                   <p class="card-text">Price : tk 150</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Mango Milk">
                  <input type="hidden" name="price" value="150">
               </div>
           </div>
           </form>
       </div>

       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/vanila.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Vanilla Ice-cream</h5>
                   <p class="card-text">Price : tk 50</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Vanila icecream">
                  <input type="hidden" name="price" value="50">
               </div>
           </div>
           </form>
       </div>
       <div class="col-lg-3">
       <form action="manage_cart.php" method="POST">
           <div class="card">
               <img src="img/strawberry.jpg" alt="">
               <div class="card-body">
                   <h5 class="card-title">Strawberry Ice-Cream</h5>
                   <p class="card-text">Price : tk 170</p>
                  <button type="submit" name="add_to_cart" class="btnn">Add to Cart</button>
                  <input type="hidden" name="item_name" value="Strawberry ice-cream">
                  <input type="hidden" name="price" value="170">
               </div>
           </div>
           </form>
           
       </div>
      
     
       
   </div>
</div>
</body>
</html>